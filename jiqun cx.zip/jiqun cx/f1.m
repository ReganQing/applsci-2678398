function fv=f1(x) 
fv=sum((x-50).^2); 