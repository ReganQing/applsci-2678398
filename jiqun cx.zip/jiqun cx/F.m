function fv=F(x)
fv=f1(x); 