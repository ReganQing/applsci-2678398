function fv=fa(x) 
fv=0.25*f1(x)+0.25*f2(x)+0.25*f3(x)+0.25*f16(x); 