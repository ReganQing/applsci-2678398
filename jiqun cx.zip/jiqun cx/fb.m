function fv=fb(x) 
fv=0.5*f9(x)+0.5*f10(x); 