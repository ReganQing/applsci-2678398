function fv=f3(x) 
fv=max(abs(x-50));