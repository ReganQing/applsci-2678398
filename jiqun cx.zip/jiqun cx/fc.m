function fv=fc(x) 
fv=0.5*f6(x)+0.5*f11(x); 